context('Test main presto runs on variety of input types')

library(presto)

set.seed(42)
exprs <- matrix(rpois(25 * 150, lambda = 2), nrow = 25,
                dimnames = list(paste0("G", 1:25), NULL))
y <- rep(c("A", "B", "C"), each = 50)

test_that('presto executes on all dense and sparse 2D inputs', {
    N <- nrow(exprs) * length(unique(y))

    res_matrix <- wilcoxauc(as(exprs, 'matrix'), y)
    expect_equal(dim(res_matrix), c(N, 10))
    expect_true(all(!is.na(res_matrix)))

    res_dge <- wilcoxauc(as(exprs, 'dgeMatrix'), y)
    expect_equal(dim(res_dge), c(N, 10))
    expect_true(all(!is.na(res_dge)))

    res_dgt <- wilcoxauc(as(exprs, 'dgTMatrix'), y)
    expect_equal(dim(res_dgt), c(N, 10))
    expect_true(all(!is.na(res_dgt)))

    res_tsparse <- wilcoxauc(as(exprs, 'TsparseMatrix'), y)
    expect_equal(dim(res_tsparse), c(N, 10))
    expect_true(all(!is.na(res_tsparse)))

    res_dgc <- wilcoxauc(as(exprs, 'dgCMatrix'), y)
    expect_equal(dim(res_dgc), c(N, 10))
    expect_true(all(!is.na(res_dgc)))

    res_df <- wilcoxauc(as.data.frame(exprs), y)
    expect_equal(dim(res_df), c(N, 10))
    expect_true(all(!is.na(res_df)))
})


check_seurat <- function() {
    if (!requireNamespace('Seurat', quietly = TRUE)) {
        skip('Seurat V3 not available')
    } else {
        pkg_version <- packageVersion('Seurat')
        if (pkg_version < "3.0") {
            skip('Seurat V3 not available')
        }
    }
}

test_that("Seurat V3 interface works", {
    check_seurat()
    object_seurat <- toy_seurat()
    res <- wilcoxauc(object_seurat, "cell_type")
    expect_equal(dim(res), c(40, 10))
    expect_true(all(!is.na(res)))
})


test_that('SingleCellExperiment interface works', {
    if (!requireNamespace('SingleCellExperiment', quietly = TRUE)) {
        skip('SingleCellExperiment not available')
    }

    object_sce <- toy_sce()
    res <- wilcoxauc(object_sce, 'cell_type')
    expect_equal(dim(res), c(40, 10))
    expect_true(all(!is.na(res)))
})


test_that('toy generators are deterministic and preserve RNG state', {
    if (!requireNamespace('SingleCellExperiment', quietly = TRUE)) {
        skip('SingleCellExperiment not available')
    }

    set.seed(123)
    before <- .Random.seed
    a <- toy_sce()
    expect_identical(.Random.seed, before)

    b <- toy_sce()
    expect_identical(
        SummarizedExperiment::assay(a, 'counts'),
        SummarizedExperiment::assay(b, 'counts')
    )
})
